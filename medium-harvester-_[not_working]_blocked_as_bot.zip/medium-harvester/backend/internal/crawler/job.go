package crawler

import (
	"context"
	"fmt"
	"log"
	"math/rand"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"

	"github.com/chromedp/cdproto/network"
	"github.com/chromedp/cdproto/page"
	"github.com/chromedp/chromedp"
)

// ─── Types ────────────────────────────────────────────────────────────────────

type Cookie struct {
	Name     string `json:"name"`
	Value    string `json:"value"`
	Domain   string `json:"domain"`
	Path     string `json:"path"`
	Secure   bool   `json:"secure"`
	HTTPOnly bool   `json:"httpOnly"`
}

type LogEntry struct {
	Time    string `json:"time"`
	Level   string `json:"level"`
	Message string `json:"message"`
}

type FileResult struct {
	Name string `json:"name"`
	Path string `json:"path"`
	URL  string `json:"url"`
}

type JobStatus struct {
	ID    string       `json:"id"`
	URL   string       `json:"url"`
	State string       `json:"state"`
	Logs  []LogEntry   `json:"logs"`
	Files []FileResult `json:"files"`
	Error string       `json:"error,omitempty"`
}

type Job struct {
	id        string
	url       string
	cookies   []Cookie
	outputDir string

	mu          sync.RWMutex
	state       string
	logs        []LogEntry
	files       []FileResult
	errMsg      string
	subscribers map[chan LogEntry]struct{}
	stopOnce    sync.Once
	stopCh      chan struct{}
}

func NewJob(id, rawURL string, cookies []Cookie, outputDir string) *Job {
	return &Job{
		id:          id,
		url:         rawURL,
		cookies:     cookies,
		outputDir:   outputDir,
		state:       "queued",
		subscribers: make(map[chan LogEntry]struct{}),
		stopCh:      make(chan struct{}),
	}
}

// Stop signals the job to cancel as soon as possible.
func (j *Job) Stop() {
	j.stopOnce.Do(func() { close(j.stopCh) })
}

func (j *Job) Subscribe() chan LogEntry {
	ch := make(chan LogEntry, 128)
	j.mu.Lock()
	j.subscribers[ch] = struct{}{}
	j.mu.Unlock()
	return ch
}

func (j *Job) Unsubscribe(ch chan LogEntry) {
	j.mu.Lock()
	delete(j.subscribers, ch)
	j.mu.Unlock()
}

func (j *Job) emit(level, msg string) {
	entry := LogEntry{Time: time.Now().Format("15:04:05"), Level: level, Message: msg}
	log.Printf("[%s] %s: %s", j.id, level, msg)
	j.mu.Lock()
	j.logs = append(j.logs, entry)
	subs := make([]chan LogEntry, 0, len(j.subscribers))
	for ch := range j.subscribers {
		subs = append(subs, ch)
	}
	j.mu.Unlock()
	for _, ch := range subs {
		select {
		case ch <- entry:
		default:
		}
	}
}

func (j *Job) addFile(name, relPath, srcURL string) {
	j.mu.Lock()
	j.files = append(j.files, FileResult{Name: name, Path: relPath, URL: srcURL})
	j.mu.Unlock()
}

func (j *Job) Status() JobStatus {
	j.mu.RLock()
	defer j.mu.RUnlock()
	return JobStatus{ID: j.id, URL: j.url, State: j.state, Logs: j.logs, Files: j.files, Error: j.errMsg}
}

func (j *Job) setState(s string) {
	j.mu.Lock()
	j.state = s
	j.mu.Unlock()
}

// ─── Run ──────────────────────────────────────────────────────────────────────

func (j *Job) Run() {
	j.setState("running")
	j.emit("info", fmt.Sprintf("Starting harvest for %s", j.url))

	if err := os.MkdirAll(filepath.Join(j.outputDir, "main"), 0755); err != nil {
		j.fail(err); return
	}
	if err := os.MkdirAll(filepath.Join(j.outputDir, "pages"), 0755); err != nil {
		j.fail(err); return
	}

	ctx, cancel := j.newCtx()
	defer cancel()

	// 1. Navigate master page and collect links
	j.emit("info", "Navigating to master page...")
	links, err := j.collectLinks(ctx, j.url)
	if err != nil {
		j.fail(fmt.Errorf("collect links: %w", err)); return
	}
	j.emit("info", fmt.Sprintf("Found %d linked Medium articles", len(links)))

	// 2. Master page → PDF
	mainPDFPath := filepath.Join(j.outputDir, "main", "main.pdf")
	j.emit("info", "Converting master page to PDF...")
	if err := j.printToPDF(ctx, j.url, mainPDFPath); err != nil {
		j.fail(fmt.Errorf("print master PDF: %w", err)); return
	}
	j.addFile("main.pdf", "main/main.pdf", j.url)
	j.emit("ok", "Master PDF saved → main/main.pdf")

	// 3. Each linked page → PDF
	pageMap := map[string]string{}
	for i, link := range links {
		// Check for stop signal before each page
		select {
		case <-j.stopCh:
			j.emit("warn", "Harvest stopped by user")
			j.setState("stopped")
			j.closeSubscribers()
			return
		default:
		}

		safe := sanitizeFilename(link)
		pdfName := fmt.Sprintf("page_%02d_%s.pdf", i+1, safe)
		pdfPath := filepath.Join(j.outputDir, "pages", pdfName)
		relPath := "pages/" + pdfName

		j.emit("info", fmt.Sprintf("[%d/%d] %s", i+1, len(links), link))

		// human-like delay between requests (also cancellable)
		select {
		case <-j.stopCh:
			j.emit("warn", "Harvest stopped by user")
			j.setState("stopped")
			j.closeSubscribers()
			return
		case <-time.After(time.Duration(2000+rand.Intn(3000)) * time.Millisecond):
		}

		if err := j.printToPDF(ctx, link, pdfPath); err != nil {
			j.emit("warn", fmt.Sprintf("Failed: %v", err))
			continue
		}
		pageMap[link] = relPath
		j.addFile(pdfName, relPath, link)
		j.emit("ok", fmt.Sprintf("Saved → %s", relPath))
	}

	// 4. Write link-map sidecar
	if err := patchPDFLinks(mainPDFPath, pageMap); err != nil {
		j.emit("warn", fmt.Sprintf("Link sidecar: %v", err))
	} else {
		j.emit("ok", "Link map written → main/main.pdf.links.txt")
	}

	j.setState("done")
	j.emit("ok", fmt.Sprintf("✅ Done. %d PDFs generated.", len(pageMap)+1))
	j.closeSubscribers()
}

func (j *Job) fail(err error) {
	j.mu.Lock()
	j.state = "failed"
	j.errMsg = err.Error()
	j.mu.Unlock()
	j.emit("error", err.Error())
	j.closeSubscribers()
}

func (j *Job) closeSubscribers() {
	j.mu.Lock()
	for ch := range j.subscribers {
		close(ch)
	}
	j.subscribers = make(map[chan LogEntry]struct{})
	j.mu.Unlock()
}

// ─── Browser context ──────────────────────────────────────────────────────────

var userAgents = []string{
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
}

// stealthScript patches properties that bot-detection scripts fingerprint.
const stealthScript = `
(function() {
	Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
	Object.defineProperty(navigator, 'plugins',   { get: () => [1,2,3,4,5] });
	Object.defineProperty(navigator, 'languages', { get: () => ['en-US','en'] });
	window.chrome = { runtime: {}, loadTimes: function(){}, csi: function(){} };
	const origQuery = window.navigator.permissions && window.navigator.permissions.query;
	if (origQuery) {
		window.navigator.permissions.query = (p) =>
			p.name === 'notifications'
				? Promise.resolve({ state: Notification.permission })
				: origQuery(p);
	}
})();
`

func (j *Job) newCtx() (context.Context, context.CancelFunc) {
	ua := userAgents[rand.Intn(len(userAgents))]

	opts := append(chromedp.DefaultExecAllocatorOptions[:],
		chromedp.Flag("headless", true),
		chromedp.Flag("no-sandbox", true),
		chromedp.Flag("disable-setuid-sandbox", true),
		chromedp.Flag("disable-dev-shm-usage", true),
		chromedp.Flag("disable-gpu", true),
		chromedp.Flag("disable-blink-features", "AutomationControlled"),
		chromedp.Flag("disable-infobars", true),
		chromedp.Flag("window-size", "1920,1080"),
		chromedp.Flag("lang", "en-US"),
		chromedp.UserAgent(ua),
	)

	allocCtx, aCancel := chromedp.NewExecAllocator(context.Background(), opts...)
	ctx, cCancel := chromedp.NewContext(allocCtx)
	cancel := func() { cCancel(); aCancel() }

	// Inject stealth script on every new document
	if err := chromedp.Run(ctx, chromedp.ActionFunc(func(c context.Context) error {
		_, err := page.AddScriptToEvaluateOnNewDocument(stealthScript).Do(c)
		return err
	})); err != nil {
		j.emit("warn", fmt.Sprintf("Stealth inject: %v", err))
	}

	// Inject cookies via CDP network domain — most reliable method
	if len(j.cookies) > 0 {
		if err := chromedp.Run(ctx, j.cookieActions()...); err != nil {
			j.emit("warn", fmt.Sprintf("Cookie injection: %v", err))
		} else {
			j.emit("info", fmt.Sprintf("Injected %d cookies via CDP", len(j.cookies)))
		}
	}

	return ctx, cancel
}

func (j *Job) cookieActions() []chromedp.Action {
	actions := make([]chromedp.Action, 0, len(j.cookies))
	for _, c := range j.cookies {
		c := c // capture
		domain := c.Domain
		if domain == "" {
			domain = ".medium.com"
		}
		path := c.Path
		if path == "" {
			path = "/"
		}
		actions = append(actions, chromedp.ActionFunc(func(ctx context.Context) error {
			expr := network.SetCookie(c.Name, c.Value).
				WithDomain(domain).
				WithPath(path).
				WithSecure(true).
				WithHTTPOnly(c.HTTPOnly)
			return expr.Do(ctx)
		}))
	}
	return actions
}

// ─── collectLinks ─────────────────────────────────────────────────────────────

func (j *Job) collectLinks(ctx context.Context, rawURL string) ([]string, error) {
	var hrefs []string

	err := chromedp.Run(ctx,
		chromedp.Navigate(rawURL),
		chromedp.Sleep(5*time.Second),
		chromedp.Evaluate(`
			['[data-testid="close-button"]','button[aria-label="close"]','.overlay button']
			.flatMap(s=>[...document.querySelectorAll(s)])
			.forEach(b=>{ try{b.click()}catch(e){} });
		`, nil),
		chromedp.Sleep(800*time.Millisecond),
		chromedp.Evaluate(`window.scrollTo(0,document.body.scrollHeight)`, nil),
		chromedp.Sleep(1500*time.Millisecond),
		chromedp.Evaluate(`window.scrollTo(0,0)`, nil),
		chromedp.Sleep(500*time.Millisecond),
		chromedp.Evaluate(`
			Array.from(document.querySelectorAll('a[href]'))
				.map(a=>{ try{return new URL(a.href,location.href).href}catch{return ''} })
				.filter(h=>h.includes('medium.com')&&!h.includes('#'))
		`, &hrefs),
	)
	if err != nil {
		return nil, err
	}

	j.emit("info", fmt.Sprintf("Raw hrefs collected: %d", len(hrefs)))

	seen := map[string]bool{stripQuery(rawURL): true}
	var uniq []string
	for _, h := range hrefs {
		clean := stripQuery(h)
		if !seen[clean] && isMediumArticle(clean) {
			seen[clean] = true
			uniq = append(uniq, clean)
		}
	}
	return uniq, nil
}

// ─── printToPDF ───────────────────────────────────────────────────────────────

func (j *Job) printToPDF(ctx context.Context, rawURL, destPath string) error {
	var pdfBuf []byte

	err := chromedp.Run(ctx,
		chromedp.Navigate(rawURL),
		chromedp.Sleep(6*time.Second),
		// Remove paywalls and noise elements before printing
		chromedp.Evaluate(`
			['.overlay','.modal','[data-testid="paywall"]',
			 '[id*="paywall"]','[class*="paywall"]',
			 '[class*="overlay"]','[class*="banner"]',
			 '[class*="popup"]','[class*="cookie"]']
			.flatMap(s=>[...document.querySelectorAll(s)])
			.forEach(el=>el.remove());
		`, nil),
		// Trigger lazy-loading by scrolling
		chromedp.Evaluate(`window.scrollTo(0,document.body.scrollHeight)`, nil),
		chromedp.Sleep(2*time.Second),
		chromedp.Evaluate(`window.scrollTo(0,0)`, nil),
		chromedp.Sleep(500*time.Millisecond),
		// Print using cdproto page.PrintToPDF (verified API)
		chromedp.ActionFunc(func(c context.Context) error {
			var err error
			pdfBuf, _, err = page.PrintToPDF().
				WithPrintBackground(true).
				WithPaperWidth(8.27).
				WithPaperHeight(11.69).
				WithMarginTop(0.4).
				WithMarginBottom(0.4).
				WithMarginLeft(0.4).
				WithMarginRight(0.4).
				WithPreferCSSPageSize(false).
				Do(c)
			return err
		}),
	)
	if err != nil {
		return err
	}
	return os.WriteFile(destPath, pdfBuf, 0644)
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

var mediumPathRe = regexp.MustCompile(`^/@?[^/]+/[a-zA-Z0-9_-]{5,}`)

func isMediumArticle(rawURL string) bool {
	u, err := url.Parse(rawURL)
	if err != nil {
		return false
	}
	if !strings.Contains(u.Hostname(), "medium.com") {
		return false
	}
	for _, skip := range []string{"/tag/", "/topics/", "/me/", "/sign", "/about", "/membership", "/new-story"} {
		if strings.HasPrefix(u.Path, skip) {
			return false
		}
	}
	return mediumPathRe.MatchString(u.Path)
}

func stripQuery(rawURL string) string {
	if i := strings.IndexAny(rawURL, "?#"); i != -1 {
		return rawURL[:i]
	}
	return rawURL
}

var nonAlnum = regexp.MustCompile(`[^a-zA-Z0-9_-]`)

func sanitizeFilename(rawURL string) string {
	u, err := url.Parse(rawURL)
	if err != nil {
		return "page"
	}
	slug := strings.TrimPrefix(u.Path, "/")
	slug = strings.ReplaceAll(slug, "/", "_")
	slug = nonAlnum.ReplaceAllString(slug, "")
	if len(slug) > 60 {
		slug = slug[:60]
	}
	if slug == "" {
		slug = "page"
	}
	return slug
}

